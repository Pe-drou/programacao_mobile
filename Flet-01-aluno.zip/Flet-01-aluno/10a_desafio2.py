# 10a Desafio 2 Digitação (Aqui) 🕶️ ⌚ 🎧 📚 👕 👟 💻 📱 ❌ 🎉 ⚠️ 🛍️ 🔄


    
